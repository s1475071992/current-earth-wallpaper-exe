"""Windows 全局恢复快捷键：Ctrl+Alt+E。

托盘隐藏后仍可将后台运行的主窗口重新打开。Windows 使用 RegisterHotKey，
不依赖第三方键盘监听库，也不修改壁纸刷新线程。
"""

import ctypes
from ctypes import wintypes
import sys
import threading


HOTKEY_ID = 0xEA47
WM_HOTKEY = 0x0312
WM_QUIT = 0x0012
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_NOREPEAT = 0x4000


class RestoreHotkey:
    """工作线程接收 Windows 热键消息；GUI 主线程通过 triggered 事件响应。"""

    def __init__(self):
        self.triggered = threading.Event()
        self._ready = threading.Event()
        self._cancel = threading.Event()
        self._thread = None
        self._thread_id = None
        self._registered = False

    def start(self):
        """注册成功返回 True；失败则 UI 必须继续显示托盘图标。"""
        if sys.platform != 'win32':
            return False
        self._thread = threading.Thread(target=self._listen, daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout=2):
            self._cancel.set()
            return False
        return self._registered

    def _listen(self):
        user32 = ctypes.windll.user32
        try:
            self._thread_id = ctypes.windll.kernel32.GetCurrentThreadId()
            registered = bool(user32.RegisterHotKey(
                None, HOTKEY_ID, MOD_ALT | MOD_CONTROL | MOD_NOREPEAT, ord('E')
            ))
            self._registered = registered
            self._ready.set()
            if not registered or self._cancel.is_set():
                return
            msg = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == WM_HOTKEY and msg.wParam == HOTKEY_ID:
                    self.triggered.set()
        finally:
            if self._registered:
                user32.UnregisterHotKey(None, HOTKEY_ID)
                self._registered = False
            self._ready.set()

    def stop(self):
        """退出或重新显示托盘时释放系统快捷键。"""
        self._cancel.set()
        if self._thread_id is not None and self._thread is not None:
            ctypes.windll.user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
            self._thread.join(timeout=1)
