"""Cross-platform tests for paths used in Windows frozen builds."""
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import utils


class PackagingResourcesTests(unittest.TestCase):
    def test_development_assets_exist(self):
        self.assertTrue(Path(utils.resource_path('certs', 'cacert.pem')).is_file())
        self.assertTrue(Path(utils.resource_path('tmp.ico')).is_file())

    def test_onefile_meipass_resolves_to_extracted_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(utils.sys, '_MEIPASS', tmp, create=True):
                self.assertEqual(utils.resource_path('tmp.ico'), str(Path(tmp) / 'tmp.ico'))
                self.assertEqual(utils.resource_path('certs', 'cacert.pem'),
                                 str(Path(tmp) / 'certs' / 'cacert.pem'))

    def test_user_config_path_is_not_the_extraction_folder(self):
        with tempfile.TemporaryDirectory() as extracted:
            with patch.object(utils.sys, '_MEIPASS', extracted, create=True), \
                    patch.object(utils.sys, 'frozen', True, create=True), \
                    patch.object(utils.sys, 'executable', r'C:\Portable\CurrentEarthWallpaper.exe'):
                self.assertNotEqual(utils.app_path(), extracted)
