"""Offline simulated regression tests for satellite APIs and image conversion."""
import io
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlparse
import sys
import types

# mss is Windows-target dependency not installed in the offline build image.
sys.modules.setdefault("mss", types.ModuleType("mss"))

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from config import AppConfig, load, save
import config
from sources import SOURCES, get_image_url
from downloader import DownloadError, download_image
from wallpaper import generate_wallpaper
import wallpaper
from i18n import LANGUAGES, TRANSLATIONS


class FakeResponse:
    def __init__(self, *, payload=b'', data=None, content_type='image/jpeg', status_error=False):
        self.content = payload
        self.data = data
        self.headers = {'content-type': content_type, 'content-length': str(len(payload))}
        self.status_error = status_error

    def raise_for_status(self):
        if self.status_error:
            raise RuntimeError('Bad HTTP')

    def json(self):
        return self.data

    def iter_content(self, chunk_size=8192):
        for i in range(0, len(self.content), chunk_size):
            yield self.content[i:i + chunk_size]

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False


def small_image(size=(120, 120), format='JPEG'):
    output = io.BytesIO()
    Image.new('RGB', size, (20, 85, 150)).save(output, format=format)
    return output.getvalue()


class SourceTests(unittest.TestCase):
    def test_config_preserves_selected_new_source_and_tray_preference(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(config, 'app_path', return_value=tmp):
            for source in ('Himawari-9', 'NASA EPIC', 'Meteosat (MTG)'):
                state = AppConfig(image_source=source, show_tray_icon=False)
                save(state)
                loaded = load()
                self.assertEqual(loaded.image_source, source)
                self.assertFalse(loaded.show_tray_icon)

    def test_i18n_has_all_sources_and_hints(self):
        for lang in LANGUAGES:
            for source in SOURCES:
                self.assertIn(source, TRANSLATIONS[lang])
                self.assertIn(source + '范围', TRANSLATIONS[lang])

    def test_epic_uses_public_nasa_endpoint_without_key(self):
        fake = FakeResponse(data=[
            {'date': '2026-09-22 14:00:00', 'image': 'epic_old'},
            {'date': '2026-09-23 15:00:00', 'image': 'epic_latest'},
        ])
        with patch('sources.requests.get', return_value=fake) as get:
            url = get_image_url(SOURCES['NASA EPIC'], '/dummy.pem')
        self.assertEqual(url, 'https://epic.gsfc.nasa.gov/archive/natural/2026/09/23/jpg/epic_latest.jpg')
        self.assertEqual(get.call_args.args[0], 'https://epic.gsfc.nasa.gov/api/natural')
        self.assertNotIn('api_key', url)

    def test_wms_uses_public_rgb_layer(self):
        url = get_image_url(SOURCES['Meteosat (MTG)'], '/dummy.pem')
        parsed = urlparse(url)
        query = parse_qs(parsed.query)
        self.assertEqual(query['LAYERS'], ['mtg_fd:rgb_geocolour'])
        self.assertEqual(query['REQUEST'], ['GetMap'])
        self.assertEqual(query['SRS'], ['EPSG:4326'])
        self.assertNotIn('api_key', parsed.query.lower())
        self.assertNotIn('TIME', query)

    def test_himawari_assembles_16_tiles(self):
        source = SOURCES['Himawari-9']
        blank = small_image((550, 550), 'PNG')
        accesses = []

        def response(url, **kwargs):
            accesses.append(url)
            if url.endswith('latest.json'):
                return FakeResponse(data={'date': '2026-10-08 00:10:00'}, content_type='application/json')
            return FakeResponse(payload=blank, content_type='image/png')

        with tempfile.TemporaryDirectory() as tmp:
            ca = Path(tmp, 'ca.pem')
            ca.write_bytes(b'certificate placeholder')
            with patch('downloader.requests.get', side_effect=response):
                filename = download_image(source, tmp, str(ca), lambda s: None)
            with Image.open(filename) as image:
                self.assertEqual(image.size, (2200, 2200))
                self.assertEqual(image.format, 'JPEG')
            self.assertEqual(len(accesses), 17)
            self.assertIn('/4d/550/2026/10/08/001000_3_3.png', accesses[-1])

    def test_wms_image_download_and_conversion(self):
        png = small_image((400, 400), 'PNG')
        with tempfile.TemporaryDirectory() as tmp:
            ca = Path(tmp, 'ca.pem')
            ca.write_bytes(b'certificate placeholder')
            with patch('downloader.requests.get', return_value=FakeResponse(payload=png, content_type='image/png')):
                filename = download_image(SOURCES['Meteosat (MTG)'], tmp, str(ca), lambda s: None)
            with Image.open(filename) as image:
                self.assertEqual(image.format, 'JPEG')
                self.assertEqual(image.size, (400, 400))

    def test_nasa_jpeg_download_is_not_renamed_until_closed(self):
        jpeg = small_image((256, 256), 'JPEG')
        metadata = FakeResponse(data=[{'date': '2026-10-08 00:00:00', 'image': 'epic_1b_20261008000000'}])
        image_response = FakeResponse(payload=jpeg, content_type='image/jpeg')
        with tempfile.TemporaryDirectory() as tmp:
            ca = Path(tmp, 'ca.pem')
            ca.write_bytes(b'certificate placeholder')
            with patch('downloader.requests.get', side_effect=[metadata, image_response]):
                path = download_image(SOURCES['NASA EPIC'], tmp, str(ca), lambda s: None)
            with Image.open(path) as image:
                self.assertEqual(image.format, 'JPEG')
            self.assertFalse(list(Path(tmp).glob('*.part')))

    def test_rejects_xml_service_exception(self):
        with tempfile.TemporaryDirectory() as tmp:
            ca = Path(tmp, 'ca.pem')
            ca.write_bytes(b'certificate placeholder')
            with patch('downloader.requests.get', return_value=FakeResponse(
                    payload=b'<ServiceException>Oops</ServiceException>', content_type='text/xml')):
                with self.assertRaises(DownloadError):
                    download_image(SOURCES['Meteosat (MTG)'], tmp, str(ca), lambda s: None)
            self.assertFalse(list(Path(tmp).glob('*.jpg')))

    def test_wallpaper_handles_dynamic_crop_sources(self):
        with tempfile.TemporaryDirectory() as tmp:
            original = Path(tmp, 'test.jpg')
            Image.new('RGB', (600, 600), (15, 120, 210)).save(original)
            with patch.object(wallpaper, 'get_screen_size', return_value=(800, 600)):
                for key in ('Himawari-9', 'NASA EPIC', 'Meteosat (MTG)'):
                    new_path = generate_wallpaper(str(original), tmp, key,
                                                  SOURCES[key], 2, False, lambda s: None)
                    with Image.open(new_path) as image:
                        self.assertEqual(image.size, (800, 600))


if __name__ == '__main__':
    unittest.main()
