"""托盘隐藏功能的非 Windows 环境回归测试。"""

import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import queue
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config
from i18n import LANGUAGES, TRANSLATIONS
import restore_hotkey


class FakeUser32:
    def __init__(self, register_result=True):
        self.register_result = register_result
        self.messages = queue.Queue()
        self.unregister_calls = 0
        self.register_calls = 0

    def RegisterHotKey(self, hwnd, hotkey_id, modifiers, vk):
        self.register_calls += 1
        assert modifiers & restore_hotkey.MOD_CONTROL
        assert modifiers & restore_hotkey.MOD_ALT
        assert vk == ord('E')
        return int(self.register_result)

    def GetMessageW(self, msg_ptr, _hwnd, _min, _max):
        message = self.messages.get(timeout=3)
        if message == restore_hotkey.WM_QUIT:
            return 0
        msg = ctypes.cast(msg_ptr, ctypes.POINTER(wintypes.MSG)).contents
        msg.message = message
        msg.wParam = restore_hotkey.HOTKEY_ID
        return 1

    def PostThreadMessageW(self, thread_id, message, wparam, lparam):
        self.messages.put(message)
        return 1

    def UnregisterHotKey(self, hwnd, hotkey_id):
        self.unregister_calls += 1
        return 1


class HotkeyTests(unittest.TestCase):
    def test_hotkey_can_start_receive_event_and_stop(self):
        user32 = FakeUser32()
        fake_dll = types.SimpleNamespace(
            user32=user32,
            kernel32=types.SimpleNamespace(GetCurrentThreadId=lambda: 99),
        )
        with patch.object(restore_hotkey.sys, 'platform', 'win32'), \
                patch.object(restore_hotkey.ctypes, 'windll', fake_dll, create=True):
            hotkey = restore_hotkey.RestoreHotkey()
            self.assertTrue(hotkey.start(), 'Start must finish before the message loop stops')
            user32.messages.put(restore_hotkey.WM_HOTKEY)
            self.assertTrue(hotkey.triggered.wait(1))
            hotkey.stop()
        self.assertEqual(user32.register_calls, 1)
        self.assertEqual(user32.unregister_calls, 1)

    def test_occupied_shortcut_cannot_enable_hidden_mode(self):
        user32 = FakeUser32(register_result=False)
        fake_dll = types.SimpleNamespace(
            user32=user32,
            kernel32=types.SimpleNamespace(GetCurrentThreadId=lambda: 99),
        )
        with patch.object(restore_hotkey.sys, 'platform', 'win32'), \
                patch.object(restore_hotkey.ctypes, 'windll', fake_dll, create=True):
            hotkey = restore_hotkey.RestoreHotkey()
            self.assertFalse(hotkey.start())
        self.assertEqual(user32.unregister_calls, 0)


class ConfigTests(unittest.TestCase):
    def test_old_config_defaults_to_visible_and_toggle_persists(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(config, 'app_path', return_value=tmp):
            (Path(tmp) / config.CONFIG_FILE).write_text('{"language":"中文"}', encoding='utf8')
            app_config = config.load()
            self.assertTrue(app_config.show_tray_icon)
            app_config.show_tray_icon = False
            config.save(app_config)
            self.assertFalse(config.load().show_tray_icon)
            self.assertFalse(json.loads((Path(tmp) / config.CONFIG_FILE).read_text(encoding='utf8'))['show_tray_icon'])

    def test_all_translations_complete(self):
        keys = ['显示托盘图标', '托盘图标描述', '托盘隐藏提示', '快捷键注册失败']
        for lang in LANGUAGES:
            for key in keys:
                self.assertIn(key, TRANSLATIONS[lang], (lang, key))


class UiBehaviorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # ui.py 仅在 Windows 启动；这里替换不参与测试的 GUI/系统依赖。
        fake_ctk = types.ModuleType('customtkinter')
        fake_ctk.CTkFrame = type('CTkFrame', (), {})
        fake_pystray = types.ModuleType('pystray')
        fake_winreg = types.ModuleType('winreg')
        fake_wallpaper = types.ModuleType('wallpaper')
        fake_wallpaper.SCALE_MODES = {}
        patches = [patch.dict(sys.modules, {
            'customtkinter': fake_ctk,
            'pystray': fake_pystray,
            'winreg': fake_winreg,
            'wallpaper': fake_wallpaper,
        })]
        cls.module_patch = patches[0]
        cls.module_patch.start()
        import ui
        cls.ui = ui

    @classmethod
    def tearDownClass(cls):
        cls.module_patch.stop()
        sys.modules.pop('ui', None)

    def new_window(self, initially_visible=True):
        window = self.ui.MainWindow.__new__(self.ui.MainWindow)
        window.app = types.SimpleNamespace(state=config.AppConfig(show_tray_icon=initially_visible))
        window.tray_switch = MagicMock()
        window.tray_switch.get.return_value = not initially_visible
        window._tray_lock = threading.Lock()
        window._tray_ready = threading.Event()
        window._tray_ready.set()
        window.icon = types.SimpleNamespace(visible=initially_visible)
        window._restore_hotkey = None
        window._render = MagicMock()
        window._show_error = MagicMock()
        return window

    def test_hide_then_show_icon_without_stopping_app(self):
        window = self.new_window()
        fake_hotkey = MagicMock()
        fake_hotkey.start.return_value = True
        with patch.object(self.ui, 'RestoreHotkey', return_value=fake_hotkey), \
                patch.object(self.ui.config, 'save') as save:
            window._on_tray_visibility_changed()
            self.assertFalse(window.icon.visible)
            self.assertFalse(window.app.state.show_tray_icon)
            self.assertIs(window._restore_hotkey, fake_hotkey)
            window.tray_switch.get.return_value = True
            window._on_tray_visibility_changed()
            self.assertTrue(window.icon.visible)
            self.assertTrue(window.app.state.show_tray_icon)
            self.assertIsNone(window._restore_hotkey)
            self.assertEqual(save.call_count, 2)
            fake_hotkey.stop.assert_called_once()

    def test_tray_setup_uses_current_saved_preference(self):
        window = self.new_window(initially_visible=False)
        window._tray_ready.clear()
        window._on_tray_ready(window.icon)
        self.assertTrue(window._tray_ready.is_set())
        self.assertFalse(window.icon.visible)

    def test_no_hotkey_keeps_tray_visible(self):
        window = self.new_window()
        fake_hotkey = MagicMock()
        fake_hotkey.start.return_value = False
        with patch.object(self.ui, 'RestoreHotkey', return_value=fake_hotkey), \
                patch.object(self.ui.config, 'save') as save:
            window._on_tray_visibility_changed()
        self.assertTrue(window.icon.visible)
        self.assertTrue(window.app.state.show_tray_icon)
        window.tray_switch.select.assert_called_once()
        window._show_error.assert_called_once()
        save.assert_not_called()


if __name__ == '__main__':
    unittest.main()
