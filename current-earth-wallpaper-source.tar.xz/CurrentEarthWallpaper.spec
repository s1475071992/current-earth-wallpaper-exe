# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller Windows x64 portable single-executable build configuration.

Build on native Windows with Python 3.12 or 3.13 (build_windows.bat).
Bundled assets are accessed via utils.resource_path() at runtime.
User settings and other writable output are kept separate from _MEIPASS.
"""
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files

root = Path(SPECPATH)
assets = collect_data_files('customtkinter')
assets.extend([
    (str(root / 'certs' / 'cacert.pem'), 'certs'),
    (str(root / 'tmp.ico'), '.'),
])

a = Analysis(
    [str(root / 'main.py')],
    pathex=[str(root)],
    binaries=[],
    datas=assets,
    hiddenimports=['pystray._win32'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='CurrentEarthWallpaper',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=str(root / 'tmp.ico'),
    version=str(root / 'version-file.txt'),
    disable_windowed_traceback=False,
)
