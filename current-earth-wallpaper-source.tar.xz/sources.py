"""Satellite imagery provider definitions and the public, no-login URL resolvers."""
import re
import time
from dataclasses import dataclass
from datetime import datetime
from urllib.parse import urlencode, urljoin, urlparse

import requests
from bs4 import BeautifulSoup


@dataclass(frozen=True)
class ImageSource:
    """Source metadata; crop_size=0 uses the largest centered square dynamically."""
    name: str
    home_url: str
    direct: bool
    crop_size: int
    crop_x: int
    crop_y: int
    kind: str = 'legacy'     # legacy, himawari, epic or wms


SOURCES = {
    '风云4B': ImageSource(
        name='风云4B',
        home_url='http://img.nsmc.org.cn/CLOUDIMAGE/FY4B/AGRI/GCLR/FY4B_DISK_GCLR.JPG',
        direct=True, crop_size=10835, crop_x=65, crop_y=80,
    ),
    'GOES-East': ImageSource(
        name='GOES-East',
        home_url='https://www.star.nesdis.noaa.gov/goes/fulldisk.php?sat=G19',
        direct=False, crop_size=10800, crop_x=24, crop_y=24,
    ),
    'GOES-West': ImageSource(
        name='GOES-West',
        home_url='https://www.star.nesdis.noaa.gov/goes/fulldisk.php?sat=G18',
        direct=False, crop_size=10800, crop_x=24, crop_y=24,
    ),
    # NICT visualisation imagery is public without an account; no commercial use.
    'Himawari-9': ImageSource(
        name='Himawari-9',
        home_url='https://himawari8-dl.nict.go.jp/himawari8/img/D531106',
        direct=False, crop_size=0, crop_x=0, crop_y=0, kind='himawari',
    ),
    # Use the original EPIC public endpoint, which does not require NASA API keys.
    'NASA EPIC': ImageSource(
        name='NASA EPIC',
        home_url='https://epic.gsfc.nasa.gov/api/natural',
        direct=False, crop_size=0, crop_x=0, crop_y=0, kind='epic',
    ),
    # EUMETView's public WMS visualisation layer (not EUMETSAT Data Store).
    'Meteosat (MTG)': ImageSource(
        name='Meteosat (MTG)',
        home_url='https://view.eumetsat.int/geoserver/wms',
        direct=False, crop_size=0, crop_x=0, crop_y=0, kind='wms',
    ),
}

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'),
}


def get_image_url(source, cert_path, timeout=15):
    """Resolve a single public image URL. Tile sources are handled by downloader."""
    if source.direct:
        return source.home_url

    if source.kind == 'wms':
        # WMS 1.1.1 uses lon,lat in BBOX with EPSG:4326. Without TIME, latest is used.
        params = {
            'SERVICE': 'WMS', 'VERSION': '1.1.1', 'REQUEST': 'GetMap',
            'LAYERS': 'mtg_fd:rgb_geocolour', 'STYLES': '',
            'FORMAT': 'image/jpeg', 'SRS': 'EPSG:4326',
            'BBOX': '-77,-77,77,77', 'WIDTH': '1600', 'HEIGHT': '1600',
            'TRANSPARENT': 'FALSE', 'BGCOLOR': '0x000000',
        }
        return f'{source.home_url}?{urlencode(params)}'

    if source.kind == 'epic':
        response = requests.get(source.home_url, verify=cert_path,
                                headers=_HEADERS, timeout=timeout)
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, list) or not data:
            raise RuntimeError('NASA EPIC did not return any available imagery')
        latest = max(data, key=lambda item: item.get('date', ''))
        name = latest.get('image', '')
        date = latest.get('date', '')[:10]
        # Restrict filename components to prevent malformed or unsafe archive paths.
        if not isinstance(name, str) or not re.fullmatch(r'[a-zA-Z0-9_-]+', name):
            raise RuntimeError('NASA EPIC returned an invalid image name')
        try:
            observation = datetime.strptime(date, '%Y-%m-%d')
        except (TypeError, ValueError) as e:
            raise RuntimeError('NASA EPIC returned an invalid observation date') from e
        return (f'https://epic.gsfc.nasa.gov/archive/natural/'
                f'{observation:%Y/%m/%d}/jpg/{name}.jpg')

    if source.kind == 'himawari':
        raise ValueError('Himawari tiles must be assembled by the downloader')

    response = requests.get(source.home_url, verify=cert_path,
                            headers=_HEADERS, timeout=timeout)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    pattern = re.compile(r'GEOCOLOR-10848x10848.jpg', re.IGNORECASE)
    for link in soup.find_all('a'):
        href = link.get('href', '')
        if pattern.search(href):
            full_url = urljoin(source.home_url, href)
            if not urlparse(full_url).query:
                full_url += f'?t={int(time.time())}'
            return full_url
    raise RuntimeError("No links containing 'GEOCOLOR-10848x10848.jpg' were found")
