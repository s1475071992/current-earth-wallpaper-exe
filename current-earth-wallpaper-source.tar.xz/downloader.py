"""Download or assemble the most recent imagery from the selected provider."""
import io
import os
import re
import time
from datetime import datetime

import requests
from PIL import Image, UnidentifiedImageError

from sources import get_image_url

MAX_FILES = 96
CHUNK_SIZE = 8192
OWN_FILE_RE = re.compile(r'^(resize_)?\d{8}_\d{6}\.jpg$')
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')


class DownloadError(Exception):
    """Download error handled and retried by the application's scheduler."""


def _clean_old_files(save_path, log):
    own = [f for f in os.listdir(save_path) if OWN_FILE_RE.match(f)]
    if len(own) > MAX_FILES:
        own.sort(key=lambda x: os.path.getctime(os.path.join(save_path, x)), reverse=True)
        for name in own[MAX_FILES:]:
            os.remove(os.path.join(save_path, name))
        log(f'Deleted {len(own) - MAX_FILES} oldest files from {save_path}')


def _new_image_path(save_path):
    return os.path.join(save_path, datetime.now().strftime('%Y%m%d_%H%M%S') + '.jpg')


def _download_himawari(source, save_path, cert_path, log):
    """Compose the free NICT 4x4 tiles into one 2200x2200 full disk JPG."""
    base = source.home_url.rstrip('/')
    size = 4
    tile_pixels = 550
    try:
        response = requests.get(base + '/latest.json', verify=cert_path,
                                headers={'User-Agent': USER_AGENT}, timeout=20)
        response.raise_for_status()
        stamp = datetime.strptime(response.json()['date'], '%Y-%m-%d %H:%M:%S')
        image = Image.new('RGB', (size * tile_pixels, size * tile_pixels))
        for y in range(size):
            for x in range(size):
                url = f'{base}/{size}d/550/{stamp:%Y/%m/%d/%H%M%S}_{x}_{y}.png'
                tile_response = requests.get(url, verify=cert_path,
                                             headers={'User-Agent': USER_AGENT},
                                             timeout=40)
                tile_response.raise_for_status()
                with Image.open(io.BytesIO(tile_response.content)) as tile:
                    tile.load()
                    tile_rgb = tile.convert('RGB')
                    if tile_rgb.size != (tile_pixels, tile_pixels):
                        raise DownloadError(f'Unexpected Himawari tile size: {tile_rgb.size}')
                    image.paste(tile_rgb, (x * tile_pixels, y * tile_pixels))
        dest = _new_image_path(save_path)
        image.save(dest, format='JPEG', quality=94)
        log(f'Himawari 4x4 tiles assembled: {stamp:%Y-%m-%d %H:%M UTC}')
        _clean_old_files(save_path, log)
        return dest
    except (requests.exceptions.RequestException, OSError, UnidentifiedImageError,
            KeyError, ValueError) as e:
        raise DownloadError(f'Himawari tile download failed: {e}') from e


def download_image(source, save_path, cert_path, log):
    """Download latest full-disk satellite image to a JPG file and return its path."""
    log(f"Time: {datetime.now().strftime('%Y%m%d_%H%M%S')}")
    log(f'Image source: {source.name}')
    log('Image download begin')
    if not os.path.exists(cert_path):
        raise DownloadError(f"CA certificate doesn't exist: {cert_path}")
    log('CA certificate successfully loaded')
    if source.kind == 'himawari':
        return _download_himawari(source, save_path, cert_path, log)

    try:
        image_url = get_image_url(source, cert_path)
    except requests.exceptions.RequestException as e:
        raise DownloadError(f'Network request failed: {e}') from e
    except Exception as e:
        raise DownloadError(f'Image address resolution failed: {e}') from e

    start_time = time.time()
    file_path = _new_image_path(save_path)
    temp_path = file_path + '.part'
    downloaded_size = 0
    try:
        with requests.get(image_url, verify=cert_path,
                          headers={'User-Agent': USER_AGENT},
                          stream=True, timeout=60) as response:
            response.raise_for_status()
            mime_type = response.headers.get('content-type', '').lower()
            if mime_type and not mime_type.startswith('image/'):
                raise DownloadError(f'The satellite server did not return an image ({mime_type})')
            total_size = int(response.headers.get('content-length', 0))
            log(f'Image Size: {total_size / (1024 * 1024):.2f} MB')
            next_threshold = 25
            with open(temp_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                    if not chunk:
                        continue
                    f.write(chunk)
                    downloaded_size += len(chunk)
                    if total_size > 0 and downloaded_size / total_size * 100 >= next_threshold:
                        log(f'Download progress: {downloaded_size / total_size * 100:.1f}%')
                        next_threshold = min(101, next_threshold + 25)
        # WMS errors may be returned as XML with a misleading status. Validate image data.
        with Image.open(temp_path) as img:
            img.load()
            is_jpeg_passthrough = source.kind != 'wms' and img.format == 'JPEG'
            if not is_jpeg_passthrough:
                img.convert('RGB').save(file_path, format='JPEG', quality=93)
        # Close the Pillow file handle before renaming: Windows locks open files.
        if is_jpeg_passthrough:
            os.replace(temp_path, file_path)
        elif os.path.exists(temp_path):
            os.remove(temp_path)
        log('Image download successful')
        log(f'Total time consumption: {time.time() - start_time:.2f} s')
        _clean_old_files(save_path, log)
        return file_path
    except DownloadError:
        raise
    except (requests.exceptions.RequestException, OSError, UnidentifiedImageError,
            ValueError) as e:
        raise DownloadError(f'Error during image download: {e}') from e
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                pass
